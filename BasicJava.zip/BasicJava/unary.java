class Main {
    public static void main(String[] args) {
        int a=12 , b=12 ;
        int result1 , result2 ;
        System.out.println("Value of a:" +a);
        result1 = ++a;
        System.out.println("After increment: " +result1);
        System.out.println("Value of b:" +b);
        System.out.println("After decrement: " +result2);
    }
}