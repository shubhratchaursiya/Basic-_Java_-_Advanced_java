public class BitwiseAND {
    public static void main(String[] args) {
        int number1=12 , number2=25 , result;
        result = number1 & number2;
           System.out.println(result); 
        }
}
